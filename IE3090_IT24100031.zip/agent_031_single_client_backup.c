#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/stat.h>
#include <errno.h>

#define PORT 9410
#define SID "1300"
#define AUTH_TOKEN "OPS-0031"

#define STORAGE_DIR "./agentfiles/IT24100031/"
#define MAX_LINE 1024
#define MAX_FILENAME 255
#define MAX_FILE_SIZE (10 * 1024 * 1024)

int send_all(int socket_fd, const void *buffer, size_t length)
{
    size_t total_sent = 0;
    const char *data = (const char *)buffer;

    while (total_sent < length)
    {
        ssize_t sent = send(socket_fd,
                            data + total_sent,
                            length - total_sent,
                            0);

        if (sent <= 0)
        {
            return -1;
        }

        total_sent += (size_t)sent;
    }

    return 0;
}

int recv_line(int socket_fd, char *buffer, size_t buffer_size)
{
    size_t position = 0;

    while (position < buffer_size - 1)
    {
        char character;

        ssize_t received = recv(socket_fd,
                                &character,
                                1,
                                0);

        if (received == 0)
        {
            return 0;
        }

        if (received < 0)
        {
            return -1;
        }

        buffer[position] = character;
        position++;

        if (character == '\n')
        {
            break;
        }
    }

    buffer[position] = '\0';

    return 1;
}

int recv_exact(int socket_fd, void *buffer, size_t length)
{
    size_t total_received = 0;
    char *data = (char *)buffer;

    while (total_received < length)
    {
        ssize_t received = recv(socket_fd,
                                data + total_received,
                                length - total_received,
                                0);

        if (received <= 0)
        {
            return -1;
        }

        total_received += (size_t)received;
    }

    return 0;
}

int send_response(int socket_fd, const char *message)
{
    char response[MAX_LINE];

    snprintf(response,
             sizeof(response),
             "%s SID:%s\n",
             message,
             SID);

    return send_all(socket_fd,
                    response,
                    strlen(response));
}

int valid_filename(const char *filename)
{
    if (filename == NULL)
    {
        return 0;
    }

    if (strlen(filename) == 0)
    {
        return 0;
    }

    if (strstr(filename, "..") != NULL)
    {
        return 0;
    }

    if (strchr(filename, '/') != NULL)
    {
        return 0;
    }

    if (strchr(filename, '\\') != NULL)
    {
        return 0;
    }

    return 1;
}

void send_sysinfo(int client_socket)
{
    FILE *file;

    double load_average = 0.0;
    double uptime = 0.0;

    long memory_total = 0;
    long memory_available = 0;
    long memory_used = 0;

    char line[256];

    file = fopen("/proc/loadavg", "r");

    if (file != NULL)
    {
        fscanf(file,
               "%lf",
               &load_average);

        fclose(file);
    }

    file = fopen("/proc/uptime", "r");

    if (file != NULL)
    {
        fscanf(file,
               "%lf",
               &uptime);

        fclose(file);
    }

    file = fopen("/proc/meminfo", "r");

    if (file != NULL)
    {
        while (fgets(line,
                     sizeof(line),
                     file) != NULL)
        {
            if (sscanf(line,
                       "MemTotal: %ld kB",
                       &memory_total) == 1)
            {
                continue;
            }

            if (sscanf(line,
                       "MemAvailable: %ld kB",
                       &memory_available) == 1)
            {
                continue;
            }
        }

        fclose(file);
    }

    memory_used = memory_total - memory_available;

    char response[MAX_LINE];

    snprintf(response,
             sizeof(response),
             "OK SYSINFO %.2f %ld %.0f",
             load_average,
             memory_used,
             uptime);

    send_response(client_socket,
                  response);
}

void send_listproc(int client_socket)
{
    FILE *process_file;

    char line[256];
    char process_list[MAX_LINE];

    process_list[0] = '\0';

    process_file = popen("ps -eo pid,comm --no-headers",
                         "r");

    if (process_file == NULL)
    {
        send_response(client_socket,
                      "ERR 003 PROCESS_LIST_FAILED");

        return;
    }

    while (fgets(line,
                 sizeof(line),
                 process_file) != NULL)
    {
        int pid;
        char command[200];

        if (sscanf(line,
                   "%d %199s",
                   &pid,
                   command) == 2)
        {
            char item[256];

            snprintf(item,
                     sizeof(item),
                     "%d/%s,",
                     pid,
                     command);

            if (strlen(process_list) +
                strlen(item) <
                MAX_LINE - 32)
            {
                strcat(process_list,
                       item);
            }
            else
            {
                break;
            }
        }
    }

    pclose(process_file);

    if (strlen(process_list) > 0)
    {
        process_list[strlen(process_list) - 1] = '\0';
    }

    char response[MAX_LINE];

    /*
     * Limit the amount of process_list copied into
     * the response buffer.
     *
     * "OK PROCS " uses 9 characters.
     * MAX_LINE - 10 leaves room for the final '\0'.
     */
    snprintf(response,
             sizeof(response),
             "OK PROCS %.*s",
             MAX_LINE - 10,
             process_list);

    send_response(client_socket,
                  response);
}

void execute_command(int client_socket,
                     const char *command)
{
    char shell_command[100];
    char output[700];
    char line[256];

    output[0] = '\0';

    if (strcmp(command,
               "DATE") == 0)
    {
        strcpy(shell_command,
               "date");
    }
    else if (strcmp(command,
                    "UPTIME") == 0)
    {
        strcpy(shell_command,
               "uptime");
    }
    else if (strcmp(command,
                    "DISKFREE") == 0)
    {
        strcpy(shell_command,
               "df -h /");
    }
    else if (strcmp(command,
                    "HOSTNAME") == 0)
    {
        strcpy(shell_command,
               "hostname");
    }
    else if (strcmp(command,
                    "WHOAMI") == 0)
    {
        strcpy(shell_command,
               "whoami");
    }
    else
    {
        send_response(client_socket,
                      "ERR 002 COMMAND_NOT_ALLOWED");

        return;
    }

    FILE *command_output = popen(shell_command,
                                  "r");

    if (command_output == NULL)
    {
        send_response(client_socket,
                      "ERR 006 EXEC_FAILED");

        return;
    }

    while (fgets(line,
                 sizeof(line),
                 command_output) != NULL)
    {
        size_t i;

        /*
         * Replace newline and carriage-return
         * characters with spaces.
         *
         * This prevents one EXEC response from
         * becoming multiple protocol lines.
         */
        for (i = 0;
             line[i] != '\0';
             i++)
        {
            if (line[i] == '\n' ||
                line[i] == '\r')
            {
                line[i] = ' ';
            }
        }

        if (strlen(output) +
            strlen(line) <
            sizeof(output) - 1)
        {
            strcat(output,
                   line);
        }
    }

    pclose(command_output);

    /*
     * Remove spaces from the end.
     */
    while (strlen(output) > 0 &&
           output[strlen(output) - 1] == ' ')
    {
        output[strlen(output) - 1] = '\0';
    }

    char response[MAX_LINE];

    snprintf(response,
             sizeof(response),
             "OK EXEC_RESULT %s",
             output);

    send_response(client_socket,
                  response);
}

void handle_put(int client_socket,
                const char *command)
{
    char filename[MAX_FILENAME + 1];

    unsigned long long file_size;

    int parsed = sscanf(command,
                        "PUT %255s %llu",
                        filename,
                        &file_size);

    if (parsed != 2)
    {
        send_response(client_socket,
                      "ERR 001 INVALID_COMMAND");

        return;
    }

    if (!valid_filename(filename))
    {
        send_response(client_socket,
                      "ERR 007 INVALID_FILENAME");

        return;
    }

    if (file_size > MAX_FILE_SIZE)
    {
        send_response(client_socket,
                      "ERR 004 FILE_TOO_LARGE");

        return;
    }

    mkdir("./agentfiles",
          0755);

    mkdir(STORAGE_DIR,
          0755);

    char file_path[MAX_LINE];

    snprintf(file_path,
             sizeof(file_path),
             "%s%s",
             STORAGE_DIR,
             filename);

    FILE *file = fopen(file_path,
                       "wb");

    if (file == NULL)
    {
        send_response(client_socket,
                      "ERR 008 FILE_OPEN_FAILED");

        return;
    }

    char buffer[4096];

    unsigned long long remaining = file_size;

    while (remaining > 0)
    {
        size_t chunk_size;

        if (remaining > sizeof(buffer))
        {
            chunk_size = sizeof(buffer);
        }
        else
        {
            chunk_size = (size_t)remaining;
        }

        if (recv_exact(client_socket,
                       buffer,
                       chunk_size) != 0)
        {
            fclose(file);

            remove(file_path);

            return;
        }

        size_t written = fwrite(buffer,
                                1,
                                chunk_size,
                                file);

        if (written != chunk_size)
        {
            fclose(file);

            remove(file_path);

            send_response(client_socket,
                          "ERR 009 FILE_WRITE_FAILED");

            return;
        }

        remaining -= chunk_size;
    }

    fclose(file);

    char response[MAX_LINE];

    snprintf(response,
             sizeof(response),
             "OK FILE_RECEIVED %s",
             filename);

    send_response(client_socket,
                  response);

    printf("PUT completed: %s (%llu bytes)\n",
           filename,
           file_size);
}

void handle_get(int client_socket,
                const char *command)
{
    char filename[MAX_FILENAME + 1];

    int parsed = sscanf(command,
                        "GET %255s",
                        filename);

    if (parsed != 1)
    {
        send_response(client_socket,
                      "ERR 001 INVALID_COMMAND");

        return;
    }

    if (!valid_filename(filename))
    {
        send_response(client_socket,
                      "ERR 007 INVALID_FILENAME");

        return;
    }

    char file_path[MAX_LINE];

    snprintf(file_path,
             sizeof(file_path),
             "%s%s",
             STORAGE_DIR,
             filename);

    struct stat file_information;

    if (stat(file_path,
             &file_information) != 0)
    {
        send_response(client_socket,
                      "ERR 005 FILE_NOT_FOUND");

        return;
    }

    unsigned long long file_size =
        (unsigned long long)file_information.st_size;

    FILE *file = fopen(file_path,
                       "rb");

    if (file == NULL)
    {
        send_response(client_socket,
                      "ERR 010 FILE_READ_FAILED");

        return;
    }

    char header[MAX_LINE];

    snprintf(header,
             sizeof(header),
             "OK FILE_SEND %s %llu SID:%s\n",
             filename,
             file_size,
             SID);

    if (send_all(client_socket,
                 header,
                 strlen(header)) != 0)
    {
        fclose(file);

        return;
    }

    char buffer[4096];

    unsigned long long remaining = file_size;

    while (remaining > 0)
    {
        size_t chunk_size;

        if (remaining > sizeof(buffer))
        {
            chunk_size = sizeof(buffer);
        }
        else
        {
            chunk_size = (size_t)remaining;
        }

        size_t bytes_read = fread(buffer,
                                  1,
                                  chunk_size,
                                  file);

        if (bytes_read != chunk_size)
        {
            fclose(file);

            return;
        }

        if (send_all(client_socket,
                     buffer,
                     bytes_read) != 0)
        {
            fclose(file);

            return;
        }

        remaining -= bytes_read;
    }

    fclose(file);

    printf("GET completed: %s (%llu bytes)\n",
           filename,
           file_size);
}

int main()
{
    int server_socket;
    int client_socket;

    struct sockaddr_in server_address;
    struct sockaddr_in client_address;

    socklen_t client_address_length;

    int option = 1;

    server_socket = socket(AF_INET,
                           SOCK_STREAM,
                           0);

    if (server_socket == -1)
    {
        perror("socket");

        return 1;
    }

    printf("Agent socket created successfully.\n");

    setsockopt(server_socket,
               SOL_SOCKET,
               SO_REUSEADDR,
               &option,
               sizeof(option));

    memset(&server_address,
           0,
           sizeof(server_address));

    server_address.sin_family = AF_INET;

    server_address.sin_addr.s_addr =
        INADDR_ANY;

    server_address.sin_port =
        htons(PORT);

    if (bind(server_socket,
             (struct sockaddr *)&server_address,
             sizeof(server_address)) == -1)
    {
        perror("bind");

        close(server_socket);

        return 1;
    }

    printf("Socket bound to port %d.\n",
           PORT);

    if (listen(server_socket,
               5) == -1)
    {
        perror("listen");

        close(server_socket);

        return 1;
    }

    printf("Agent is listening on port %d...\n",
           PORT);

    client_address_length =
        sizeof(client_address);

    client_socket = accept(server_socket,
                           (struct sockaddr *)&client_address,
                           &client_address_length);

    if (client_socket == -1)
    {
        perror("accept");

        close(server_socket);

        return 1;
    }

    printf("Controller connected successfully.\n");

    int authenticated = 0;

    while (1)
    {
        char command[MAX_LINE];

        int result = recv_line(client_socket,
                               command,
                               sizeof(command));

        if (result <= 0)
        {
            break;
        }

        command[strcspn(command,
                        "\r\n")] = '\0';

        printf("Command received: %s\n",
               command);

        if (strncmp(command,
                    "AUTH ",
                    5) == 0)
        {
            char expected_auth[MAX_LINE];

            snprintf(expected_auth,
                     sizeof(expected_auth),
                     "AUTH %s",
                     AUTH_TOKEN);

            if (strcmp(command,
                       expected_auth) == 0)
            {
                authenticated = 1;

                send_response(client_socket,
                              "OK AUTHENTICATED");

                printf("Authentication successful.\n");
            }
            else
            {
                send_response(client_socket,
                              "ERR 003 AUTH_FAILED");

                printf("Authentication failed.\n");
            }

            continue;
        }

        if (!authenticated)
        {
            send_response(client_socket,
                          "ERR 003 NOT_AUTHENTICATED");

            continue;
        }

        if (strcmp(command,
                   "SYSINFO") == 0)
        {
            send_sysinfo(client_socket);
        }
        else if (strcmp(command,
                        "LISTPROC") == 0)
        {
            send_listproc(client_socket);
        }
        else if (strncmp(command,
                         "EXEC ",
                         5) == 0)
        {
            execute_command(client_socket,
                            command + 5);
        }
        else if (strncmp(command,
                         "PUT ",
                         4) == 0)
        {
            handle_put(client_socket,
                       command);
        }
        else if (strncmp(command,
                         "GET ",
                         4) == 0)
        {
            handle_get(client_socket,
                       command);
        }
        else if (strcmp(command,
                        "QUIT") == 0)
        {
            send_response(client_socket,
                          "OK BYE");

            break;
        }
        else
        {
            send_response(client_socket,
                          "ERR 001 UNKNOWN_COMMAND");
        }
    }

    close(client_socket);

    close(server_socket);

    printf("Agent shutdown complete.\n");

    return 0;
}
