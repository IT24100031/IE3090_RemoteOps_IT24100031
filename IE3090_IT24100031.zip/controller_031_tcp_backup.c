#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define SERVER_IP "127.0.0.1"
#define PORT 9410
#define SID "1300"

int send_all(int socket_fd, const void *buffer, size_t length)
{
    size_t total_sent = 0;
    const char *data = (const char *)buffer;

    while (total_sent < length)
    {
        ssize_t sent = send(socket_fd,
                            data + total_sent,
                            length - total_sent,
                            0);

        if (sent <= 0)
        {
            return -1;
        }

        total_sent += (size_t)sent;
    }

    return 0;
}

int recv_line(int socket_fd, char *buffer, size_t buffer_size)
{
    size_t position = 0;

    while (position < buffer_size - 1)
    {
        char character;

        ssize_t received = recv(socket_fd,
                                &character,
                                1,
                                0);

        if (received == 0)
        {
            return 0;
        }

        if (received < 0)
        {
            return -1;
        }

        buffer[position] = character;
        position++;

        if (character == '\n')
        {
            break;
        }
    }

    buffer[position] = '\0';

    return 1;
}

int recv_exact(int socket_fd, void *buffer, size_t length)
{
    size_t total_received = 0;
    char *data = (char *)buffer;

    while (total_received < length)
    {
        ssize_t received = recv(socket_fd,
                                data + total_received,
                                length - total_received,
                                0);

        if (received <= 0)
        {
            return -1;
        }

        total_received += (size_t)received;
    }

    return 0;
}

int send_command(int socket_fd, const char *command)
{
    char message[1024];

    snprintf(message,
             sizeof(message),
             "%s\n",
             command);

    printf("Sent: %s\n", command);

    return send_all(socket_fd,
                    message,
                    strlen(message));
}

int receive_response(int socket_fd)
{
    char response[1024];

    int result = recv_line(socket_fd,
                           response,
                           sizeof(response));

    if (result <= 0)
    {
        return -1;
    }

    response[strcspn(response, "\r\n")] = '\0';

    printf("Received: %s\n",
           response);

    return 0;
}

int send_put(int socket_fd,
             const char *filename)
{
    FILE *file = fopen(filename, "rb");

    if (file == NULL)
    {
        perror("fopen");
        return -1;
    }

    fseek(file, 0, SEEK_END);

    long file_size = ftell(file);

    fseek(file, 0, SEEK_SET);

    if (file_size < 0)
    {
        fclose(file);
        return -1;
    }

    char command[1024];

    snprintf(command,
             sizeof(command),
             "PUT %s %ld",
             filename,
             file_size);

    printf("Sending PUT: %s (%ld bytes)\n",
           filename,
           file_size);

    if (send_command(socket_fd,
                     command) != 0)
    {
        fclose(file);
        return -1;
    }

    char buffer[4096];

    long remaining = file_size;

    while (remaining > 0)
    {
        size_t chunk_size;

        if (remaining > (long)sizeof(buffer))
        {
            chunk_size = sizeof(buffer);
        }
        else
        {
            chunk_size = (size_t)remaining;
        }

        size_t bytes_read = fread(buffer,
                                  1,
                                  chunk_size,
                                  file);

        if (bytes_read != chunk_size)
        {
            fclose(file);
            return -1;
        }

        if (send_all(socket_fd,
                     buffer,
                     bytes_read) != 0)
        {
            fclose(file);
            return -1;
        }

        remaining -= (long)bytes_read;
    }

    fclose(file);

    char response[1024];

    if (recv_line(socket_fd,
                  response,
                  sizeof(response)) <= 0)
    {
        return -1;
    }

    response[strcspn(response, "\r\n")] = '\0';

    printf("PUT response: %s\n",
           response);

    return 0;
}

int send_get_file(int socket_fd,
                  const char *filename,
                  const char *output_filename)
{
    char command[1024];

    snprintf(command,
             sizeof(command),
             "GET %s",
             filename);

    if (send_command(socket_fd,
                     command) != 0)
    {
        return -1;
    }

    char header[1024];

    if (recv_line(socket_fd,
                  header,
                  sizeof(header)) <= 0)
    {
        return -1;
    }

    header[strcspn(header, "\r\n")] = '\0';

    printf("GET header: %s\n",
           header);

    char received_filename[1024];
    char received_sid[64];
    unsigned long long file_size;

    int parsed = sscanf(header,
                        "OK FILE_SEND %1023s %llu SID:%63s",
                        received_filename,
                        &file_size,
                        received_sid);

    if (parsed != 3)
    {
        printf("GET failed: invalid response.\n");
        return -1;
    }

    FILE *output_file = fopen(output_filename,
                              "wb");

    if (output_file == NULL)
    {
        perror("fopen");
        return -1;
    }

    char buffer[4096];

    unsigned long long remaining = file_size;

    while (remaining > 0)
    {
        size_t chunk_size;

        if (remaining > sizeof(buffer))
        {
            chunk_size = sizeof(buffer);
        }
        else
        {
            chunk_size = (size_t)remaining;
        }

        if (recv_exact(socket_fd,
                       buffer,
                       chunk_size) != 0)
        {
            fclose(output_file);
            return -1;
        }

        size_t written = fwrite(buffer,
                                1,
                                chunk_size,
                                output_file);

        if (written != chunk_size)
        {
            fclose(output_file);
            return -1;
        }

        remaining -= chunk_size;
    }

    fclose(output_file);

    printf("GET completed: %s -> %s (%llu bytes)\n",
           filename,
           output_filename,
           file_size);

    return 0;
}

int main()
{
    int client_socket;

    struct sockaddr_in server_address;

    client_socket = socket(AF_INET,
                           SOCK_STREAM,
                           0);

    if (client_socket == -1)
    {
        perror("socket");
        return 1;
    }

    printf("Controller socket created successfully.\n");

    memset(&server_address,
           0,
           sizeof(server_address));

    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(PORT);

    int result = inet_pton(AF_INET,
                           SERVER_IP,
                           &server_address.sin_addr);

    if (result <= 0)
    {
        printf("Invalid server IP address.\n");
        close(client_socket);
        return 1;
    }

    printf("Connecting to Agent...\n");

    result = connect(client_socket,
                     (struct sockaddr *)&server_address,
                     sizeof(server_address));

    if (result == -1)
    {
        perror("connect");
        close(client_socket);
        return 1;
    }

    printf("Connected to Agent successfully.\n");

    send_command(client_socket,
                 "AUTH OPS-0031");

    receive_response(client_socket);

    send_command(client_socket,
                 "SYSINFO");

    receive_response(client_socket);

    send_command(client_socket,
                 "LISTPROC");

    receive_response(client_socket);

    send_command(client_socket,
                 "EXEC DATE");

    receive_response(client_socket);

    send_command(client_socket,
                 "EXEC UPTIME");

    receive_response(client_socket);

    send_command(client_socket,
                 "EXEC DISKFREE");

    receive_response(client_socket);

    send_command(client_socket,
                 "EXEC HOSTNAME");

    receive_response(client_socket);

    send_command(client_socket,
                 "EXEC WHOAMI");

    receive_response(client_socket);

    send_command(client_socket,
                 "EXEC LS");

    receive_response(client_socket);

    send_put(client_socket,
             "test_upload.txt");

    send_get_file(client_socket,
                  "test_upload.txt",
                  "downloaded_test.txt");

    send_command(client_socket,
                 "QUIT");

    receive_response(client_socket);

    close(client_socket);

    printf("Controller shutdown complete.\n");

    return 0;
}
