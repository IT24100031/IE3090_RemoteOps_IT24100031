#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <errno.h>

#define PORT 9410

#define SID "1300"
#define AUTH_TOKEN "OPS-0031"

#define STORAGE_DIR "./agentfiles/IT24100031/"

#define MAX_LINE 1024
#define MAX_FILENAME 255
#define MAX_FILE_SIZE (10 * 1024 * 1024)


/*
 * Send all bytes through a socket.
 */
int send_all(int socket_fd, const void *buffer, size_t length)
{
    size_t total_sent = 0;

    while (total_sent < length)
    {
        ssize_t bytes_sent = send(
            socket_fd,
            (const char *)buffer + total_sent,
            length - total_sent,
            0
        );

        if (bytes_sent <= 0)
        {
            return -1;
        }

        total_sent += bytes_sent;
    }

    return 0;
}


/*
 * Receive one line ending with '\n'.
 */
int recv_line(int socket_fd, char *buffer, size_t buffer_size)
{
    size_t index = 0;

    while (index < buffer_size - 1)
    {
        char character;

        ssize_t bytes_received = recv(
            socket_fd,
            &character,
            1,
            0
        );

        if (bytes_received <= 0)
        {
            return -1;
        }

        if (character == '\n')
        {
            buffer[index] = '\0';
            return 0;
        }

        buffer[index] = character;
        index++;
    }

    buffer[buffer_size - 1] = '\0';

    return -1;
}


/*
 * Receive exactly the requested number of bytes.
 */
int recv_exact(int socket_fd, void *buffer, size_t length)
{
    size_t total_received = 0;

    while (total_received < length)
    {
        ssize_t bytes_received = recv(
            socket_fd,
            (char *)buffer + total_received,
            length - total_received,
            0
        );

        if (bytes_received <= 0)
        {
            return -1;
        }

        total_received += bytes_received;
    }

    return 0;
}


/*
 * Send a normal protocol response.
 * Every response contains the session ID.
 */
int send_response(int socket_fd, const char *message)
{
    char response[MAX_LINE];

    snprintf(
        response,
        sizeof(response),
        "%s SID:%s\n",
        message,
        SID
    );

    return send_all(
        socket_fd,
        response,
        strlen(response)
    );
}


/*
 * Check whether a filename is safe.
 */
int valid_filename(const char *filename)
{
    if (filename == NULL)
    {
        return 0;
    }

    if (strlen(filename) == 0)
    {
        return 0;
    }

    if (strlen(filename) > MAX_FILENAME)
    {
        return 0;
    }

    if (strstr(filename, "..") != NULL)
    {
        return 0;
    }

    if (strchr(filename, '/') != NULL)
    {
        return 0;
    }

    if (strchr(filename, '\\') != NULL)
    {
        return 0;
    }

    return 1;
}


/*
 * Send system information.
 */
void send_sysinfo(int socket_fd)
{
    FILE *file;

    char line[256];

    double load_average = 0.0;

    long memory_total = 0;
    long memory_available = 0;

    long uptime_seconds = 0;


    /*
     * Read CPU load average.
     */
    file = fopen("/proc/loadavg", "r");

    if (file != NULL)
    {
        if (fscanf(file, "%lf", &load_average) != 1)
        {
            load_average = 0.0;
        }

        fclose(file);
    }


    /*
     * Read memory information.
     */
    file = fopen("/proc/meminfo", "r");

    if (file != NULL)
    {
        while (fgets(line, sizeof(line), file) != NULL)
        {
            if (sscanf(line, "MemTotal: %ld kB", &memory_total) == 1)
            {
                continue;
            }

            if (sscanf(line, "MemAvailable: %ld kB", &memory_available) == 1)
            {
                continue;
            }
        }

        fclose(file);
    }


    /*
     * Read system uptime.
     */
    file = fopen("/proc/uptime", "r");

    if (file != NULL)
    {
        double uptime_value = 0.0;

        if (fscanf(file, "%lf", &uptime_value) == 1)
        {
            uptime_seconds = (long)uptime_value;
        }

        fclose(file);
    }


    long memory_used = memory_total - memory_available;

    char response[MAX_LINE];

    snprintf(
        response,
        sizeof(response),
        "OK SYSINFO %.2f %ld %ld",
        load_average,
        memory_used,
        uptime_seconds
    );

    send_response(socket_fd, response);
}


/*
 * Send running process information.
 */
void send_listproc(int socket_fd)
{
    FILE *process_file;

    char process_list[MAX_LINE];

    char line[256];

    process_list[0] = '\0';


    process_file = popen(
        "ps -eo pid,comm --no-headers",
        "r"
    );

    if (process_file == NULL)
    {
        send_response(
            socket_fd,
            "ERR 500 PROCESS_LIST_FAILED"
        );

        return;
    }


    while (fgets(line, sizeof(line), process_file) != NULL)
    {
        size_t current_length = strlen(process_list);
        size_t line_length = strlen(line);

        if (current_length + line_length + 1 < sizeof(process_list))
        {
            strcat(process_list, line);
        }
        else
        {
            break;
        }
    }


    pclose(process_file);


    /*
     * Replace newline characters so the response
     * remains one protocol line.
     */
    size_t index;

    for (index = 0; index < strlen(process_list); index++)
    {
        if (process_list[index] == '\n' ||
            process_list[index] == '\r')
        {
            process_list[index] = ' ';
        }
    }


    char response[MAX_LINE];

    snprintf(
        response,
        sizeof(response),
        "OK PROCS %.*s",
        MAX_LINE - 20,
        process_list
    );

    send_response(socket_fd, response);
}


/*
 * Execute only the allowed commands.
 *
 * Allowed:
 * DATE
 * UPTIME
 * DISKFREE
 * HOSTNAME
 * WHOAMI
 */
void execute_command(int socket_fd, const char *command)
{
    char system_command[256];

    char result[MAX_LINE];

    FILE *command_output;


    if (strcmp(command, "DATE") == 0)
    {
        strcpy(system_command, "date");
    }
    else if (strcmp(command, "UPTIME") == 0)
    {
        strcpy(system_command, "uptime");
    }
    else if (strcmp(command, "DISKFREE") == 0)
    {
        strcpy(system_command, "df -h /");
    }
    else if (strcmp(command, "HOSTNAME") == 0)
    {
        strcpy(system_command, "hostname");
    }
    else if (strcmp(command, "WHOAMI") == 0)
    {
        strcpy(system_command, "whoami");
    }
    else
    {
        send_response(
            socket_fd,
            "ERR 002 COMMAND_NOT_ALLOWED"
        );

        return;
    }


    command_output = popen(
        system_command,
        "r"
    );

    if (command_output == NULL)
    {
        send_response(
            socket_fd,
            "ERR 500 COMMAND_EXECUTION_FAILED"
        );

        return;
    }


    result[0] = '\0';


    while (fgets(
        result + strlen(result),
        sizeof(result) - strlen(result),
        command_output
    ) != NULL)
    {
        if (strlen(result) >= sizeof(result) - 1)
        {
            break;
        }
    }


    pclose(command_output);


    /*
     * Convert newline characters to spaces.
     * This is important because our TCP protocol
     * uses one line per response.
     */
    size_t index;

    for (index = 0; index < strlen(result); index++)
    {
        if (result[index] == '\n' ||
            result[index] == '\r')
        {
            result[index] = ' ';
        }
    }


    /*
     * Remove trailing spaces.
     */
    while (strlen(result) > 0 &&
           result[strlen(result) - 1] == ' ')
    {
        result[strlen(result) - 1] = '\0';
    }


    char response[MAX_LINE];

    snprintf(
        response,
        sizeof(response),
        "OK EXEC_RESULT %.*s",
        MAX_LINE - 30,
        result
    );

    send_response(socket_fd, response);
}


/*
 * Handle PUT command.
 *
 * PUT filename filesize
 * followed by exactly filesize raw bytes.
 */
void handle_put(
    int socket_fd,
    const char *filename,
    unsigned long long file_size
)
{
    if (!valid_filename(filename))
    {
        send_response(
            socket_fd,
            "ERR 003 INVALID_FILENAME"
        );

        return;
    }


    if (file_size > MAX_FILE_SIZE)
    {
        send_response(
            socket_fd,
            "ERR 004 FILE_TOO_LARGE"
        );

        return;
    }


    char path[512];

    snprintf(
        path,
        sizeof(path),
        "%s%s",
        STORAGE_DIR,
        filename
    );


    FILE *file = fopen(path, "wb");

    if (file == NULL)
    {
        send_response(
            socket_fd,
            "ERR 500 FILE_OPEN_FAILED"
        );

        return;
    }


    unsigned char buffer[4096];

    unsigned long long remaining = file_size;


    while (remaining > 0)
    {
        size_t chunk_size;

        if (remaining > sizeof(buffer))
        {
            chunk_size = sizeof(buffer);
        }
        else
        {
            chunk_size = (size_t)remaining;
        }


        if (recv_exact(
            socket_fd,
            buffer,
            chunk_size
        ) != 0)
        {
            fclose(file);

            remove(path);

            return;
        }


        size_t bytes_written = fwrite(
            buffer,
            1,
            chunk_size,
            file
        );

        if (bytes_written != chunk_size)
        {
            fclose(file);

            remove(path);

            send_response(
                socket_fd,
                "ERR 500 FILE_WRITE_FAILED"
            );

            return;
        }


        remaining -= chunk_size;
    }


    fclose(file);


    char response[MAX_LINE];

    snprintf(
        response,
        sizeof(response),
        "OK FILE_RECEIVED %s",
        filename
    );

    send_response(socket_fd, response);


    printf(
        "PUT completed: %s (%llu bytes)\n",
        filename,
        file_size
    );
}


/*
 * Handle GET command.
 */
void handle_get(
    int socket_fd,
    const char *filename
)
{
    if (!valid_filename(filename))
    {
        send_response(
            socket_fd,
            "ERR 003 INVALID_FILENAME"
        );

        return;
    }


    char path[512];

    snprintf(
        path,
        sizeof(path),
        "%s%s",
        STORAGE_DIR,
        filename
    );


    FILE *file = fopen(path, "rb");

    if (file == NULL)
    {
        send_response(
            socket_fd,
            "ERR 404 FILE_NOT_FOUND"
        );

        return;
    }


    /*
     * Determine file size.
     */
    if (fseek(file, 0, SEEK_END) != 0)
    {
        fclose(file);

        send_response(
            socket_fd,
            "ERR 500 FILE_SEEK_FAILED"
        );

        return;
    }


    long file_size_long = ftell(file);

    if (file_size_long < 0)
    {
        fclose(file);

        send_response(
            socket_fd,
            "ERR 500 FILE_SIZE_FAILED"
        );

        return;
    }


    rewind(file);


    unsigned long long file_size =
        (unsigned long long)file_size_long;


    if (file_size > MAX_FILE_SIZE)
    {
        fclose(file);

        send_response(
            socket_fd,
            "ERR 004 FILE_TOO_LARGE"
        );

        return;
    }


    /*
     * Send file header.
     */
    char response[MAX_LINE];

    snprintf(
        response,
        sizeof(response),
        "OK FILE_SEND %s %llu",
        filename,
        file_size
    );


    if (send_response(socket_fd, response) != 0)
    {
        fclose(file);

        return;
    }


    /*
     * Send exact file bytes.
     */
    unsigned char buffer[4096];

    unsigned long long remaining = file_size;


    while (remaining > 0)
    {
        size_t chunk_size;

        if (remaining > sizeof(buffer))
        {
            chunk_size = sizeof(buffer);
        }
        else
        {
            chunk_size = (size_t)remaining;
        }


        size_t bytes_read = fread(
            buffer,
            1,
            chunk_size,
            file
        );

        if (bytes_read != chunk_size)
        {
            fclose(file);

            return;
        }


        if (send_all(
            socket_fd,
            buffer,
            bytes_read
        ) != 0)
        {
            fclose(file);

            return;
        }


        remaining -= bytes_read;
    }


    fclose(file);


    printf(
        "GET completed: %s (%llu bytes)\n",
        filename,
        file_size
    );
}


/*
 * This function runs inside a separate pthread
 * for each Controller connection.
 */
void *handle_client(void *argument)
{
    int client_socket = *((int *)argument);

    free(argument);


    struct sockaddr_in client_address;

    socklen_t client_address_length =
        sizeof(client_address);


    if (getpeername(
        client_socket,
        (struct sockaddr *)&client_address,
        &client_address_length
    ) == 0)
    {
        printf(
            "Controller connected from %s:%d\n",
            inet_ntoa(client_address.sin_addr),
            ntohs(client_address.sin_port)
        );
    }
    else
    {
        printf("Controller connected.\n");
    }


    int authenticated = 0;

    char command_line[MAX_LINE];


    while (1)
    {
        int result = recv_line(
            client_socket,
            command_line,
            sizeof(command_line)
        );


        if (result != 0)
        {
            printf(
                "Controller disconnected.\n"
            );

            break;
        }


        printf(
            "Command received: %s\n",
            command_line
        );


        /*
         * AUTH must happen before other commands.
         */
        if (!authenticated)
        {
            if (strcmp(
                command_line,
                "AUTH " AUTH_TOKEN
            ) == 0)
            {
                authenticated = 1;

                printf(
                    "Authentication successful.\n"
                );

                send_response(
                    client_socket,
                    "OK AUTHENTICATED"
                );
            }
            else
            {
                send_response(
                    client_socket,
                    "ERR 001 AUTH_REQUIRED"
                );
            }

            continue;
        }


        /*
         * QUIT
         */
        if (strcmp(command_line, "QUIT") == 0)
        {
            send_response(
                client_socket,
                "OK BYE"
            );

            printf(
                "Controller requested disconnect.\n"
            );

            break;
        }


        /*
         * SYSINFO
         */
        if (strcmp(command_line, "SYSINFO") == 0)
        {
            send_sysinfo(client_socket);

            continue;
        }


        /*
         * LISTPROC
         */
        if (strcmp(command_line, "LISTPROC") == 0)
        {
            send_listproc(client_socket);

            continue;
        }


        /*
         * EXEC
         */
        if (strncmp(
            command_line,
            "EXEC ",
            5
        ) == 0)
        {
            const char *command =
                command_line + 5;

            execute_command(
                client_socket,
                command
            );

            continue;
        }


        /*
         * PUT
         */
        if (strncmp(
            command_line,
            "PUT ",
            4
        ) == 0)
        {
            char filename[MAX_FILENAME + 1];

            unsigned long long file_size;


            int scanned = sscanf(
                command_line + 4,
                "%255s %llu",
                filename,
                &file_size
            );


            if (scanned != 2)
            {
                send_response(
                    client_socket,
                    "ERR 005 INVALID_PUT_FORMAT"
                );

                continue;
            }


            handle_put(
                client_socket,
                filename,
                file_size
            );

            continue;
        }


        /*
         * GET
         */
        if (strncmp(
            command_line,
            "GET ",
            4
        ) == 0)
        {
            char filename[MAX_FILENAME + 1];


            int scanned = sscanf(
                command_line + 4,
                "%255s",
                filename
            );


            if (scanned != 1)
            {
                send_response(
                    client_socket,
                    "ERR 006 INVALID_GET_FORMAT"
                );

                continue;
            }


            handle_get(
                client_socket,
                filename
            );

            continue;
        }


        /*
         * Unknown command.
         */
        send_response(
            client_socket,
            "ERR 007 UNKNOWN_COMMAND"
        );
    }


    close(client_socket);


    printf(
        "Client thread finished.\n"
    );


    return NULL;
}


/*
 * Main Agent program.
 *
 * The main thread continuously accepts connections.
 * Each Controller gets its own pthread.
 */
int main(void)
{
    /*
     * Prevent the Agent process from being terminated
     * if a disconnected client causes send() to fail.
     */
    signal(SIGPIPE, SIG_IGN);


    /*
     * Create storage directory.
     */
    mkdir("./agentfiles", 0755);

    mkdir(
        STORAGE_DIR,
        0755
    );


    /*
     * Create server socket.
     */
    int server_socket = socket(
        AF_INET,
        SOCK_STREAM,
        0
    );


    if (server_socket < 0)
    {
        perror("socket");

        return 1;
    }


    printf(
        "Agent socket created successfully.\n"
    );


    /*
     * Allow quick restart of the server.
     */
    int option = 1;

    if (setsockopt(
        server_socket,
        SOL_SOCKET,
        SO_REUSEADDR,
        &option,
        sizeof(option)
    ) < 0)
    {
        perror("setsockopt");

        close(server_socket);

        return 1;
    }


    /*
     * Server address.
     */
    struct sockaddr_in server_address;

    memset(
        &server_address,
        0,
        sizeof(server_address)
    );


    server_address.sin_family = AF_INET;

    server_address.sin_addr.s_addr =
        htonl(INADDR_ANY);

    server_address.sin_port =
        htons(PORT);


    /*
     * Bind socket to port 9410.
     */
    if (bind(
        server_socket,
        (struct sockaddr *)&server_address,
        sizeof(server_address)
    ) < 0)
    {
        perror("bind");

        close(server_socket);

        return 1;
    }


    printf(
        "Socket bound to port %d.\n",
        PORT
    );


    /*
     * Start listening.
     *
     * Backlog = 5.
     */
    if (listen(server_socket, 5) < 0)
    {
        perror("listen");

        close(server_socket);

        return 1;
    }


    printf(
        "Agent is listening on port %d...\n",
        PORT
    );


    /*
     * Main accept loop.
     *
     * This loop never stops after one Controller.
     */
    while (1)
    {
        struct sockaddr_in client_address;

        socklen_t client_address_length =
            sizeof(client_address);


        int client_socket = accept(
            server_socket,
            (struct sockaddr *)&client_address,
            &client_address_length
        );


        if (client_socket < 0)
        {
            perror("accept");

            continue;
        }


        /*
         * Allocate memory for the socket descriptor.
         *
         * This is important because the new thread
         * needs its own copy of the client socket.
         */
        int *client_socket_pointer =
            malloc(sizeof(int));


        if (client_socket_pointer == NULL)
        {
            perror("malloc");

            close(client_socket);

            continue;
        }


        *client_socket_pointer =
            client_socket;


        /*
         * Create a new thread for this Controller.
         */
        pthread_t thread_id;


        int thread_result = pthread_create(
            &thread_id,
            NULL,
            handle_client,
            client_socket_pointer
        );


        if (thread_result != 0)
        {
            fprintf(
                stderr,
                "pthread_create failed: %s\n",
                strerror(thread_result)
            );

            close(client_socket);

            free(client_socket_pointer);

            continue;
        }


        /*
         * We do not need to pthread_join().
         * The thread will clean itself up after finishing.
         */
        pthread_detach(thread_id);


        printf(
            "New Controller thread created.\n"
        );
    }


    close(server_socket);

    return 0;
}
